from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from marketplace.models import UserProfile, Category, Product


class Command(BaseCommand):
    help = 'Loads categories, sample farmer, and FarmBridge produce + eggs'

    def handle(self, *args, **kwargs):
        farmer, created = User.objects.get_or_create(
            username='jean_farmer',
            defaults={'first_name': 'Jean', 'last_name': 'Habimana', 'email': 'jean@farmbridge.rw'}
        )
        if created:
            farmer.set_password('farmer1234')
            farmer.save()
            UserProfile.objects.create(
                user=farmer,
                role='farmer',
                phone='+250 788 123 456',
                location='Musanze'
            )

        categories_data = [
            ('Fruits', 'fruits'),
            ('Vegetables', 'vegetables'),
            ('Grains & Cereals', 'grains-cereals'),
            ('Roots, Tubers & Legumes', 'roots-tubers-legumes'),
            ('Poultry & Eggs', 'poultry-eggs'),
            ('Cash Crops', 'cash-crops'),
        ]
        cats = {}
        for name, slug in categories_data:
            cat, _ = Category.objects.get_or_create(name=name, slug=slug)
            cats[name] = cat

        # (Clean Name for Clients, Exact Filename in images/, Category, Price, Unit, Stock, Description)
        items = [
            ('Hass Avocados', 'Avocados.jpeg', 'Fruits', 800, 'kg', 120,
             'Freshly harvested creamy avocados ready for traders and households.'),
            ('Sweet Yellow Bananas', 'Bananas.jpeg', 'Fruits', 500, 'bunch', 85,
             'Naturally ripened sweet bananas harvested from local farms.'),
            ('Fresh Passion Fruits', 'Passion fruits.jpeg', 'Fruits', 1200, 'kg', 60,
             'Aromatic, juice-rich passion fruits great for markets and juice makers.'),

            ('Green Cabbages', 'Cabbages.jpeg', 'Vegetables', 400, 'kg', 200,
             'Crisp, fresh green cabbages sorted for bulk and retail buyers.'),
            ('Organic Carrots', 'carrot.jpeg', 'Vegetables', 600, 'kg', 95,
             'Crunchy, sweet carrots freshly picked and cleaned.'),
            ('Fresh Green Bell Peppers', 'Green peppers.jpeg', 'Vegetables', 1000, 'kg', 45,
             'Fresh green bell peppers ideal for restaurants, traders, and families.'),
            ('Vine-Ripened Red Tomatoes', 'tomatoes.jpeg', 'Vegetables', 700, 'crate', 0,
             'Fresh red tomatoes—currently marked FINISHED until the next harvest.'),

            ('Yellow Maize (Corn)', 'Maize (Corn).jpeg', 'Grains & Cereals', 450, 'kg', 500,
             'Well-dried yellow maize grains ready for traders and millers.'),
            ('Premium White Rice', 'Rice.jpeg', 'Grains & Cereals', 1100, 'kg', 350,
             'Clean, quality rice grains bagged and ready for wholesale or retail.'),
            ('Red Sorghum Grain', 'Sorghum.jpeg', 'Grains & Cereals', 550, 'kg', 240,
             'Quality sorghum grains suitable for traders, flour, and brewing.'),

            ('Dried Red Kidney Beans', 'Beans.jpeg', 'Roots, Tubers & Legumes', 950, 'kg', 300,
             'Sorted dried beans rich in protein and ready for bulk orders.'),
            ('Fresh Cassava Roots', 'Cassava.jpeg', 'Roots, Tubers & Legumes', 350, 'kg', 180,
             'Freshly harvested cassava roots for market sale or processing.'),
            ('Kinigi Irish Potatoes', 'Irish potatoes.jpeg', 'Roots, Tubers & Legumes', 420, 'kg', 400,
             'Fresh highland Irish potatoes favored by traders and restaurants.'),
            ('Orange-Fleshed Sweet Potatoes', 'Sweet potatoes.jpeg', 'Roots, Tubers & Legumes', 380, 'kg', 0,
             'Sweet potatoes—currently marked FINISHED until new stock arrives.'),

            # Change 'Eggs.jpeg' below if your eggs file has a different exact name inside images/
            ('Farm-Fresh Eggs', 'Eggs.jpeg', 'Poultry & Eggs', 3500, 'tray', 75,
             'Fresh farm eggs collected daily from healthy layers.'),

            ('Arabica Coffee Beans', 'Coffee.jpeg', 'Cash Crops', 3500, 'kg', 150,
             'Quality coffee beans harvested and dried for buyers and roasters.'),
        ]

        for display_name, filename, cat_name, price, unit, stock, desc in items:
            Product.objects.get_or_create(
                image_filename=filename,
                defaults={
                    'farmer': farmer,
                    'category': cats[cat_name],
                    'display_name': display_name,
                    'price_per_unit': price,
                    'unit': unit,
                    'stock_quantity': stock,
                    'description': desc,
                }
            )

        self.stdout.write(self.style.SUCCESS('Seeded FarmBridge categories and products successfully!'))