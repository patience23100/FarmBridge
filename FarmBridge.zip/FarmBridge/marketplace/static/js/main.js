document.addEventListener("DOMContentLoaded", function () {
    const qtyInput = document.getElementById("id_quantity");
    const priceEl = document.getElementById("unit-price-value");
    const totalEl = document.getElementById("live-total-value");
    const stockEl = document.getElementById("available-stock-value");

    if (qtyInput && priceEl && totalEl) {
        const unitPrice = parseFloat(priceEl.dataset.price || "0");
        const maxStock = stockEl ? parseInt(stockEl.dataset.stock || "0", 10) : Infinity;

        function updateTotal() {
            const qty = parseInt(qtyInput.value || "0", 10);
            if (isNaN(qty) || qty <= 0) {
                totalEl.textContent = "0";
                return;
            }
            if (qty > maxStock) {
                totalEl.textContent = "Exceeds stock (" + maxStock + " max)";
                return;
            }
            const total = qty * unitPrice;
            totalEl.textContent = total.toLocaleString();
        }

        qtyInput.addEventListener("input", updateTotal);
        updateTotal();
    }
});