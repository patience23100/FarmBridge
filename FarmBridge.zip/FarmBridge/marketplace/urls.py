from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('product/<int:pk>/', views.product_detail, name='product_detail'),
    path('my-orders/', views.my_orders, name='my_orders'),
    path('dashboard/', views.farmer_dashboard, name='farmer_dashboard'),
    path('dashboard/stock/<int:pk>/', views.update_stock, name='update_stock'),
    path('dashboard/order/<int:order_id>/', views.update_order_status, name='update_order_status'),

    path('register/', views.register_view, name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='auth/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
]