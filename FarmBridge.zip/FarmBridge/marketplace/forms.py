from django import forms
from django.contrib.auth.models import User
from .models import UserProfile, Product, Order


class RegistrationForm(forms.ModelForm):
    first_name = forms.CharField(max_length=50, required=True)
    last_name = forms.CharField(max_length=50, required=True)
    email = forms.EmailField(required=True)
    password = forms.CharField(widget=forms.PasswordInput, required=True)
    role = forms.ChoiceField(choices=UserProfile.ROLE_CHOICES, required=True)
    phone = forms.CharField(max_length=20, required=True)
    location = forms.CharField(max_length=100, required=True)

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password']


class ProductForm(forms.ModelForm):
    IMAGE_CHOICES = [
        ('Avocados.jpeg', 'Avocados.jpeg'),
        ('Bananas.jpeg', 'Bananas.jpeg'),
        ('Beans.jpeg', 'Beans.jpeg'),
        ('Cabbages.jpeg', 'Cabbages.jpeg'),
        ('carrot.jpeg', 'carrot.jpeg'),
        ('Cassava.jpeg', 'Cassava.jpeg'),
        ('Coffee.jpeg', 'Coffee.jpeg'),
        ('Eggs.jpeg', 'Eggs.jpeg'),
        ('Green peppers.jpeg', 'Green peppers.jpeg'),
        ('Irish potatoes.jpeg', 'Irish potatoes.jpeg'),
        ('Maize (Corn).jpeg', 'Maize (Corn).jpeg'),
        ('Passion fruits.jpeg', 'Passion fruits.jpeg'),
        ('Rice.jpeg', 'Rice.jpeg'),
        ('Sorghum.jpeg', 'Sorghum.jpeg'),
        ('Sweet potatoes.jpeg', 'Sweet potatoes.jpeg'),
        ('tomatoes.jpeg', 'tomatoes.jpeg'),
    ]
    image_filename = forms.ChoiceField(choices=IMAGE_CHOICES, label="Produce Image")

    class Meta:
        model = Product
        fields = ['category', 'display_name', 'image_filename', 'price_per_unit', 'unit', 'stock_quantity', 'description']


class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['quantity', 'delivery_address', 'buyer_phone']