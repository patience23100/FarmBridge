from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from .models import Category, Product, Order, UserProfile
from .forms import RegistrationForm, ProductForm, OrderForm


def home(request):
    categories = Category.objects.all()
    products = Product.objects.select_related('category', 'farmer', 'farmer__profile').all().order_by('-created_at')

    category_slug = request.GET.get('category')
    if category_slug:
        products = products.filter(category__slug=category_slug)

    status_filter = request.GET.get('status')
    if status_filter == 'available':
        products = products.filter(stock_quantity__gt=0)
    elif status_filter == 'finished':
        products = products.filter(stock_quantity=0)

    query = request.GET.get('q')
    if query:
        products = products.filter(
            Q(display_name__icontains=query) |
            Q(description__icontains=query) |
            Q(farmer__profile__location__icontains=query)
        )

    return render(request, 'home.html', {
        'categories': categories,
        'products': products,
        'selected_category': category_slug,
        'selected_status': status_filter,
        'query': query or '',
    })


def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)

    if request.method == 'POST':
        if not request.user.is_authenticated:
            messages.warning(request, "Please log in or register to place an order.")
            return redirect('login')

        if product.is_finished:
            messages.error(request, "This produce is already FINISHED (out of stock).")
            return redirect('product_detail', pk=product.pk)

        form = OrderForm(request.POST)
        if form.is_valid():
            qty = form.cleaned_data['quantity']
            if qty <= 0:
                messages.error(request, "Enter a quantity of at least 1.")
            elif qty > product.stock_quantity:
                messages.error(request, f"Only {product.stock_quantity} {product.unit} left in stock.")
            else:
                order = form.save(commit=False)
                order.buyer = request.user
                order.product = product
                order.total_price = qty * product.price_per_unit
                order.save()

                product.stock_quantity -= qty
                product.save()

                if product.stock_quantity == 0:
                    messages.success(
                        request,
                        f"Order placed! You took the last stock—{product.display_name} is now marked FINISHED."
                    )
                else:
                    messages.success(
                        request,
                        f"Order placed for {qty} {product.unit} of {product.display_name}!"
                    )
                return redirect('my_orders')
    else:
        initial_phone = ''
        initial_loc = ''
        if request.user.is_authenticated and hasattr(request.user, 'profile'):
            initial_phone = request.user.profile.phone
            initial_loc = request.user.profile.location
        form = OrderForm(initial={'buyer_phone': initial_phone, 'delivery_address': initial_loc})

    return render(request, 'product_detail.html', {'product': product, 'form': form})


def register_view(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            UserProfile.objects.create(
                user=user,
                role=form.cleaned_data['role'],
                phone=form.cleaned_data['phone'],
                location=form.cleaned_data['location'],
            )
            login(request, user)
            messages.success(request, f"Welcome to FarmBridge, {user.first_name}!")
            if form.cleaned_data['role'] == 'farmer':
                return redirect('farmer_dashboard')
            return redirect('home')
    else:
        form = RegistrationForm()
    return render(request, 'auth/register.html', {'form': form})


@login_required
def my_orders(request):
    orders = Order.objects.filter(buyer=request.user).select_related('product', 'product__farmer').order_by('-ordered_at')
    return render(request, 'my_orders.html', {'orders': orders})


@login_required
def farmer_dashboard(request):
    if not hasattr(request.user, 'profile') or request.user.profile.role != 'farmer':
        messages.error(request, "Only farmers can access the Farmer Dashboard.")
        return redirect('home')

    my_products = Product.objects.filter(farmer=request.user).order_by('-created_at')
    incoming_orders = Order.objects.filter(product__farmer=request.user).select_related('product', 'buyer').order_by('-ordered_at')

    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save(commit=False)
            product.farmer = request.user
            product.save()
            messages.success(request, f"{product.display_name} is now listed on FarmBridge!")
            return redirect('farmer_dashboard')
    else:
        form = ProductForm()

    return render(request, 'farmer_dashboard.html', {
        'my_products': my_products,
        'incoming_orders': incoming_orders,
        'form': form,
    })


@login_required
def update_stock(request, pk):
    product = get_object_or_404(Product, pk=pk, farmer=request.user)
    if request.method == 'POST':
        new_stock = int(request.POST.get('stock_quantity', 0))
        product.stock_quantity = max(0, new_stock)
        product.save()
        state = "FINISHED" if product.is_finished else f"{product.stock_quantity} {product.unit} available"
        messages.info(request, f"{product.display_name} updated: {state}.")
    return redirect('farmer_dashboard')


@login_required
def update_order_status(request, order_id):
    order = get_object_or_404(Order, id=order_id, product__farmer=request.user)
    if request.method == 'POST':
        new_status = request.POST.get('status')
        if new_status in ['pending', 'confirmed', 'delivered']:
            order.status = new_status
            order.save()
            messages.success(request, f"Order #{order.id} updated to {order.get_status_display()}.")
    return redirect('farmer_dashboard')